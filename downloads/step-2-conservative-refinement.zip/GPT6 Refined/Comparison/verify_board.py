import pcbnew as p,json,hashlib,collections
from pathlib import Path
base=Path(__file__).resolve().parent
original=base.parents[1]/'PCB Design/hw-aonic-r-drop-main-board.kicad_pcb'
refined=base.parent/'hw-aonic-r-drop-main-board.kicad_pcb'
a=p.LoadBoard(str(original)); b=p.LoadBoard(str(refined))
def xy(v): return (v.x,v.y)
def footprints(board):
    return {f.m_Uuid.AsString():[f.GetReference(),f.GetValue(),f.GetFPID().GetUniStringLibId(),xy(f.GetPosition()),f.GetOrientationDegrees(),f.GetLayer(),sorted((pad.m_Uuid.AsString(),pad.GetNumber(),pad.GetNetname(),xy(pad.GetPosition()),xy(pad.GetSize()),xy(pad.GetDrillSize()),pad.GetShape()) for pad in f.Pads())] for f in board.GetFootprints()}
def edges(board):
    return sorted((d.m_Uuid.AsString(),d.GetShape(),xy(d.GetStart()),xy(d.GetEnd()),xy(d.GetCenter()),d.GetWidth()) for d in board.GetDrawings() if d.GetLayer()==p.Edge_Cuts)
def area(board):
    return {board.GetLayerName(l):sum(z.GetFilledPolysList(l).Area()/1e12 for z in board.Zones() if z.GetNetname()=='GND' and z.IsOnLayer(l)) for l in (p.F_Cu,p.B_Cu)}
def drc(name):
    r=json.loads((base/name).read_text()); return {'errors':sum(v['severity']=='error' for v in r['violations']),'warnings':sum(v['severity']=='warning' for v in r['violations']),'unconnected':len(r['unconnected_items']),'schematic_parity':len(r['schematic_parity'])}
result={'footprints_and_pad_nets_unchanged':footprints(a)==footprints(b),'outline_and_cutouts_unchanged':edges(a)==edges(b),'copper_layers':[a.GetCopperLayerCount(),b.GetCopperLayerCount()],'footprint_count':[len(a.GetFootprints()),len(b.GetFootprints())],'via_count':[sum(type(t)==p.PCB_VIA for t in z.GetTracks()) for z in (a,b)],'ground_area_mm2':{'original':area(a),'refined':area(b)},'original_sha256':hashlib.sha256(original.read_bytes()).hexdigest(),'refined_sha256':hashlib.sha256(refined.read_bytes()).hexdigest(),'drc':{'original':drc('original-drc.json'),'refined':drc('refined-drc.json')}}
result['schematic_files_identical']=all(hashlib.sha256(f.read_bytes()).digest()==hashlib.sha256((base.parent/f.name).read_bytes()).digest() for f in original.parent.glob('*.kicad_sch'))
print(json.dumps(result,indent=2))
if footprints(a)!=footprints(b):
    fa,fb=footprints(a),footprints(b)
    print('Footprint differences:',[(k,fa[k],fb.get(k)) for k in fa if fa[k]!=fb.get(k)])
if edges(a)!=edges(b): print('Edge differences:',set(edges(a))^set(edges(b)))
assert result['footprints_and_pad_nets_unchanged'] and result['outline_and_cutouts_unchanged'] and result['schematic_files_identical']
assert result['original_sha256'].upper()=='C80D10D69F5310DE7CD80B0FB0A269AE44D5F7D4DCEDEFD1DDE41FCFE5B25DA2'
assert result['drc']['refined']['errors']==0 and result['drc']['refined']['unconnected']==0 and result['drc']['refined']['schematic_parity']==0
(base/'verification.json').write_text(json.dumps(result,indent=2)); print(json.dumps(result,indent=2))


