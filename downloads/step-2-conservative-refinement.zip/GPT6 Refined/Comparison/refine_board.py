import pcbnew as p
import json, math
from pathlib import Path

root=Path(__file__).resolve().parents[2]
src=root/'PCB Design/hw-aonic-r-drop-main-board.kicad_pcb'
dst=root/'GPT6 Refined/hw-aonic-r-drop-main-board.kicad_pcb'
b=p.LoadBoard(str(src))
changes={'engine':p.Version(),'zones':[],'tracks':[],'vias':[]}
mm=p.FromMM
for z in b.Zones():
    if z.GetNetname()=='GND' and z.GetAssignedPriority()==0:
        changes['zones'].append({'uuid':z.m_Uuid.AsString(),'layers':list(z.GetLayerSet().Seq()),'clearance_before_mm':p.ToMM(z.GetLocalClearance()),'clearance_after_mm':0.3})
        z.SetLocalClearance(mm(.3))
for t in b.GetTracks():
    if type(t)!=p.PCB_TRACK: continue
    net=t.GetNetname()
    target={'+UBEC_OUT':1.2,'+5V_1':1.5,'+5V_2':1.5}.get(net)
    if target and t.GetWidth()<mm(target):
        changes['tracks'].append({'uuid':t.m_Uuid.AsString(),'net':net,'before_mm':p.ToMM(t.GetWidth()),'after_mm':target,'length_mm':p.ToMM(t.GetLength())})
        t.SetWidth(mm(target))
filler=p.ZONE_FILLER(b)
filler.Fill(b.Zones())
gndzones={layer:z for z in b.Zones() if z.GetNetname()=='GND' and z.GetAssignedPriority()==0 for layer in z.GetLayerSet().Seq()}
existing=[t.GetPosition() for t in b.GetTracks() if type(t)==p.PCB_VIA and t.GetNetname()=='GND']
gnd=b.FindNet('GND')
# Stitch only the low-voltage area, well away from the AS5600 and battery bus.
# Nine-point copper containment leaves a margin around each proposed via.
for x in range(190,295,6):
    for y in range(104,174,6):
        if 216<x<245 and y<114: continue # conservative ESP32 antenna exclusion
        vpos=p.VECTOR2I(mm(x),mm(y))
        if any(math.hypot(p.ToMM(q.x)-x,p.ToMM(q.y)-y)<5 for q in existing): continue
        samples=[(x,y)]+[(x+.85*math.cos(a*math.pi/4),y+.85*math.sin(a*math.pi/4)) for a in range(8)]
        if not all(gndzones[l].GetFilledPolysList(l).Contains(p.VECTOR2I(mm(sx),mm(sy))) for l in (p.F_Cu,p.B_Cu) for sx,sy in samples): continue
        v=p.PCB_VIA(b)
        v.SetPosition(vpos); v.SetWidth(mm(.8)); v.SetDrill(mm(.4)); v.SetViaType(p.VIATYPE_THROUGH)
        v.SetLayerPair(p.F_Cu,p.B_Cu); v.SetNet(gnd); b.Add(v)
        changes['vias'].append({'uuid':v.m_Uuid.AsString(),'x_mm':x,'y_mm':y,'diameter_mm':.8,'drill_mm':.4})
        existing.append(vpos)
filler.Fill(b.Zones())
p.SaveBoard(str(dst),b)
(dst.parent/'Comparison/changes.json').write_text(json.dumps(changes,indent=2))
print(json.dumps({k:len(v) for k,v in changes.items() if isinstance(v,list)}))
