import pcbnew as p, json
from pathlib import Path
base=Path(__file__).resolve().parent
board=base.parent/'hw-aonic-r-drop-main-board.kicad_pcb'
b=p.LoadBoard(str(board)); changes=json.loads((base/'changes.json').read_text())
report=json.loads((base/'refined-drc.json').read_text())
bad={i['uuid'] for v in report['violations'] if v['severity']=='error' for i in v['items']}
trackmap={t.m_Uuid.AsString():t for t in b.GetTracks()}
rejected=[]
for c in changes['tracks']:
    if c['uuid'] in bad:
        trackmap[c['uuid']].SetWidth(p.FromMM(c['before_mm'])); rejected.append(c)
changes['tracks']=[c for c in changes['tracks'] if c not in rejected]
changes['rejected_width_changes']=rejected
changes['pad_connections']=[]
for f in b.GetFootprints():
    if f.GetReference()=='J301':
        for pad in f.Pads():
            if pad.GetNetname()=='GND':
                pad.SetLocalZoneConnection(p.ZONE_CONNECTION_FULL)
                changes['pad_connections'].append({'reference':'J301','pad':'1','net':'GND','connection':'solid','reason':'Eliminate isolated thermal spoke after ground refill; maintain continuous supply return.'})
p.ZONE_FILLER(b).Fill(b.Zones()); p.SaveBoard(str(board),b)
(base/'changes.json').write_text(json.dumps(changes,indent=2))
print('Accepted widened segments:',len(changes['tracks']),'reverted:',len(rejected))
