# Rdrop GPT6 / Revision A

Open `Report/index.html` for the full local website report. Open `Design/Rdrop-GPT6.kicad_pro` with KiCad 10.

The supplied default is 7.4 V servo variant A: F101 fitted, F102 DNP. Variant B swaps these fuse placements and requires a suitably rated external 5 V supply.

Only regulated 7.4 V and 5 V may enter this board. The named 3–14S UBEC cannot use an 18S pack. The selected MF-RG900-0 protection may interrupt 15 A for 30 seconds. Thermal and installed-mechanical qualification remain necessary.

ERC = 0 violations; DRC = 0 errors; unconnected = 0; schematic parity conflicts = 0. Four documented standard-library footprint warnings concern silkscreen tailoring only. `Verification/design-audit.json` verifies exact original edge geometry, mounting centers, standard pads, 0603 R/C and resolved footprints/models.

`Fabrication`: Gerbers, plated/non-plated drills, drill maps, manufacturing notes and ZIP.
`Assembly`: exact-MPN BOMs A/B, all-reference inventory, SMD and manual placements, assembly instructions.
`3D`: assembled STEP/GLB, alternative variant STEP, local component models including an explicitly approximate fuse envelope.
`Report`: website, schematic PDF, renders and layout drawings.
`Scripts`: generation history and package tooling. Do not run build_design.py on the finished project: it resets placement/routing to the generation starting point. Preserve the supplied final files.
`Tools`: portable local autorouter and runtime, retained separately and excluded from the project ZIP.

Board fabrication: two layers, 70 µm finished copper per face, nominal 1.6 mm FR4, ENIG, 0.20 mm minimum width/spacing, 0.30 mm routed-edge clearance, 0.20 mm smallest plated thermal hole. Read Fabrication-notes.txt before ordering.
